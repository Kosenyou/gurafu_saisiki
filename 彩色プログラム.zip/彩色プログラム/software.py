import networkx as nx
import matplotlib.pyplot as plt
import numpy as np
import tkinter as tk
import random
from matplotlib.figure import Figure
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk  # 画像データ用
from io import BytesIO  # バッファ管理



#データ読み込み
f = open('Graph.txt', 'r')

#データ読み取り
data = f.readline()

numbers = list(map(int, data.split()))
a, b, c = numbers  #a,b,cにそれぞれ節点数、枝数、分割数を代入。

data_rin=f.readline()

with open("Graph.txt", 'r') as file:
    lines = file.readlines()[1:a+1]  # 2行目以降を取得
    
with open("Graph.txt", 'r') as file:
    b=2*a+3
    lines2 = file.readlines()[a+2:b]
    
#グラフ作成
#無効グラフの生成
G = nx.Graph()
G1 = nx.Graph()

num_nodes = a  # ここに節点数を指定
G.add_nodes_from(range(num_nodes))

rows = lines

# 各行を空白で分割し、整数型のリストに変換
matrix = [list(map(int, row.split())) for row in rows]

# NumPy配列として行列に変換（オプション）
matrix_np = np.array(matrix)

#辺を追加
for i in range(num_nodes):
    for j in range(i + 1, num_nodes):
        if matrix_np[i, j] == 1:
            G.add_edge(i, j)

#色を追加

color=[]

rows2 = lines2

# 各行を空白で分割し、整数型のリストに変換
matrix2 = [list(map(int, row.split())) for row in rows2]

# NumPy配列として行列に変換（オプション）
matrix_np2 = np.array(matrix2)
#転置行列
#matrix_np2=matrix_np2.T

i=0
for i in range(num_nodes):
    for j in range(0, num_nodes):
        if matrix_np2[i, j] == 1:
            color.append(j+1) 

#print(color)
#print(matrix_np2)

node_colors=[]
k=0
m=0
#色を指定
for k in range(num_nodes): 
    for m in range(num_nodes):
        if(color[k]==m):
            node_colors.append(m)
        
print(node_colors)


#彩色数
painted_color_number = max(node_colors)

#色を用意
prepared_color=['black','red','blue','green','yellow','purple','orange','pink','cyan','magenta','gray','brown']

new_node_colors=[]
#色を割り当て
o=0
p=0
for o in range(num_nodes):
    for p in range(painted_color_number+1):
        if(node_colors[o]==p):
            new_node_colors.append(prepared_color[p])

#print(new_node_colors)
#new_node_colors[24]='orange'
#node_colors[24]=6

#print(new_node_colors)

used_colors=[]
for q in range(num_nodes):
    if( new_node_colors[q] not in used_colors):
        used_colors.append(new_node_colors[q])

#print(used_colors)

sorted_nodes = [[]for _ in range(painted_color_number+1)]
selected_nodes=[]
#色ごとに分ける
for q in range(num_nodes):
    for j in range (painted_color_number+1):
        if node_colors[q]==j:  
            sorted_nodes[j].append(q)
#色ごとのグラフ
red_team=sorted_nodes[1]
subgraph_red = G.subgraph(red_team)
blue_team=sorted_nodes[2]
#print(blue_team)
subgraph_blue = G.subgraph(blue_team)
green_team=sorted_nodes[3]
subgraph_green = G.subgraph(green_team)
yellow_team=sorted_nodes[4]
subgraph_yellow = G.subgraph(yellow_team)
purple_team=sorted_nodes[5]
subgraph_purple = G.subgraph(purple_team)
orange_team=sorted_nodes[6]
subgraph_orange = G.subgraph(orange_team)
G_combined2=nx.compose(subgraph_red,subgraph_blue)
G_combined3=nx.compose(G_combined2,subgraph_green)
G_combined4=nx.compose(G_combined3,subgraph_yellow)
G_combined5=nx.compose(G_combined4,subgraph_purple)
G_combined6=nx.compose(G_combined5,subgraph_orange)




pos3 = nx.circular_layout(G_combined6)
pos2 = nx.circular_layout(G)
subgraph_red_colors= [new_node_colors[node] for node in subgraph_red]
#nx.draw(G, pos3, with_labels=True, node_color=new_node_colors)
#plt.show()


pos = nx.spring_layout(G)  # グラフのレイアウトを設定


#zoom機能
class Application_zoom(tk.Frame):
    def __init__(self,master,ego_graph1,subgraph_colors,text1):
        super().__init__(master)
        print(text1)
        self.text=text1
        self.G_sp=ego_graph1
        self.colors=subgraph_colors
        self.pack() 
        self.pil_image=None# 表示する画像データ
        
        self.my_title = " Image Viewer"  # タイトル
        self.back_color = "#008B8B"     # 背景色
        
        
        # ウィンドウの設定
        
        self.master.title(self.my_title)    # タイトル
        self.master.geometry("500x400")     # サイズ
        self.create_menu()   # メニューの作成
        self.create_widget() # ウィジェットの作成
        
        
        
        
    

    def menu_quit_clicked(self):
        # ウィンドウを閉じる
        self.master.destroy() 

    # create_menuメソッドを定義
    def create_menu(self):
        self. menu_bar = tk.Menu(self) # Menuクラスからmenu_barインスタンスを生成

        self.file_menu =  tk.Menu(self.menu_bar, tearoff = tk.OFF)
        self.menu_bar.add_cascade(label="File", menu=self.file_menu)

        self.file_menu.add_command(label="Exit", command = self.menu_quit_clicked)        
        
        
        self.graph_menu = tk.Menu(self.menu_bar, tearoff=tk.OFF)  # グラフ描画用メニューを追加
        self.menu_bar.add_cascade(label="Graph", menu=self.graph_menu)
        self.graph_menu.add_command(label="Draw Graph", command=self.draw_graph)  # グラフ描画のコマンド
        
        
        self.master.config(menu=self.menu_bar) # メニューバーの配置

    
    def create_widget(self):
        '''ウィジェットの作成'''

        # ステータスバー相当(親に追加)
        self.statusbar = tk.Frame(self.master)
        self.mouse_position = tk.Label(self.statusbar, relief =  tk.SUNKEN, text="mouse position") # マウスの座標
        self.image_position = tk.Label(self.statusbar, relief = tk.SUNKEN, text="image position") # 画像の座標
        self.label_space = tk.Label(self.statusbar, relief = tk.SUNKEN)                           # 隙間を埋めるだけ
        self.image_info = tk.Label(self.statusbar, relief = tk.SUNKEN, text="image info")         # 画像情報
        self.mouse_position.pack(side=tk.LEFT)
        self.image_position.pack(side=tk.LEFT)
        self.label_space.pack(side=tk.LEFT, expand=True, fill=tk.X)
        self.image_info.pack(side=tk.RIGHT)
        self.statusbar.pack(side=tk.BOTTOM, fill=tk.X)
        

        # Canvas
        self.canvas = tk.Canvas(self.master, background= self.back_color)
        self.canvas.pack(expand=True,  fill= tk.BOTH)  # この両方でDock.Fillと同じ
        self.message=tk.Message(self,text=self.text,font=("Times New Roman", 20) ,width=350)
        self.message.pack()
        self.draw_graph()
        #  マウスイベント
        self.master.bind("<Motion>", self.mouse_move)                       # MouseMove
        self.master.bind("<B1-Motion>", self.mouse_move_left)               # MouseMove（左ボタンを押しながら移動）
        self.master.bind("<Button-1>", self.mouse_down_left)                # MouseDown（左ボタン）
        self.master.bind("<Double-Button-1>", self.mouse_double_click_left) # MouseDoubleClick（左ボタン）
        self.master.bind("<MouseWheel>", self.mouse_wheel)    # MouseWheel
        

    def draw_graph(self):
        ''' グラフを描画し、Canvasに表示する '''
        # NetworkXでサンプルグラフを作成
        plt.figure(figsize=(6, 5))
        nx.draw(self.G_sp,pos3, with_labels=True, node_color=self.colors,node_size=1000,edge_color='gray', font_size=16, font_weight='bold')
    
        # グラフをバッファに保存し、PILイメージとしてロード
        buf = BytesIO()
        plt.savefig(buf, format='png')
        buf.seek(0)
        graph_image = Image.open(buf)
        
        

        # PILイメージをTkinter Canvasで表示
        self.pil_image = graph_image
        # 画像全体に表示するようにアフィン変換行列を設定
        self.zoom_fit(self.pil_image.width, self.pil_image.height)
        # 画像の表示
        self.draw_image(self.pil_image)
        
        self.canvas.update()  # キャンバスを更新

        
    # -------------------------------------------------------------------------------
    #  マウスイベント
    # -------------------------------------------------------------------------------

    def mouse_move(self, event):
        ''' マウスの移動時 '''
        # マウス座標
        self.mouse_position["text"] = f"mouse(x, y) = ({event.x: 4d}, {event.y: 4d})"
        
        if self. pil_image == None:
            return

        # 画像座標
        mouse_posi = np.array([event.x, event.y, 1]) # マウス座標(numpyのベクトル)
        mat_inv = np.linalg.inv(self.mat_affine)     # 逆行列（画像→Cancasの変換からCanvas→画像の変換へ）
        image_posi = np.dot(mat_inv, mouse_posi)     # 座標のアフィン変換
        x = int(np.floor(image_posi[0]))
        y = int(np.floor(image_posi[1]))
        if x >= 0 and x < self.pil_image.width and y >= 0 and y < self.pil_image.height:
            # 輝度値の取得
            value = self.pil_image.getpixel((x, y))
            self.image_position["text"] = f"image({x: 4d}, {y: 4d}) = {value}"
        else:
            self.image_position["text"] = "-------------------------"

    def  mouse_move_left(self, event):
        ''' マウスの左ボタンをドラッグ '''
        if self.pil_image == None:
            return
        self.translate(event.x - self.__old_event.x, event.y - self.__old_event.y)
        self.redraw_image() # 再描画
        self.__old_event = event

    def mouse_down_left(self, event):
        '''  マウスの左ボタンを押した '''
        self.__old_event = event

    def mouse_double_click_left(self, event):
        ''' マウスの左ボタンをダブルクリック '''
        if self.pil_image == None:
            return
        self.zoom_fit(self.pil_image.width, self.pil_image.height)
        self.redraw_image() # 再描画

    def mouse_wheel(self, event):
        ''' マウスホイールを回した '''
        if self.pil_image == None:
            return

        if (event.delta < 0):
            # 上に回転の場合、縮小
            self.scale_at(0.8, event.x, event.y)
        else:
            # 下に回転の場合、拡大
            self.scale_at(1.25, event.x, event.y)
        
        self.redraw_image() # 再描画

    # -------------------------------------------------------------------------------
    # 画像表示用アフィン変換
    # -------------------------------------------------------------------------------

    def reset_transform(self):
        '''アフィン変換を初期化（スケール１、移動なし）に戻す'''
        self.mat_affine = np.eye(3) # 3x3の単位行列

    def translate(self, offset_x, offset_y):
        ''' 平行移動 '''
        mat = np.eye(3) # 3x3の単位行列
        mat[0, 2] = float(offset_x)
        mat[1, 2] = float(offset_y)

        self.mat_affine = np.dot(mat, self.mat_affine)

    def scale(self, scale:float):
        ''' 拡大縮小 '''
        mat = np.eye(3) # 単位行列
        mat[0, 0] = scale
        mat[1, 1] = scale

        self.mat_affine = np.dot(mat, self.mat_affine)

    def scale_at(self, scale:float, cx:float, cy:float):
        ''' 座標(cx, cy)を中心に拡大縮小 '''

        # 原点へ移動
        self.translate(-cx, -cy)
        # 拡大縮小
        self.scale(scale)
        # 元に戻す
        self.translate(cx, cy)

    def zoom_fit(self, image_width, image_height):
        '''画像をウィジェット全体に表示させる'''

        # キャンバスのサイズ
        canvas_width = self.canvas.winfo_width()
        canvas_height = self.canvas.winfo_height()

        if (image_width * image_height <= 0) or (canvas_width * canvas_height <= 0):
            return

        # アフィン変換の初期化
        self.reset_transform()

        scale = 1.0
        offsetx = 0.0
        offsety = 0.0

        if (canvas_width * image_height) > (image_width * canvas_height):
            # ウィジェットが横長（画像を縦に合わせる）
            scale = canvas_height / image_height
            # あまり部分の半分を中央に寄せる
            offsetx = (canvas_width - image_width * scale) / 2
        else:
            # ウィジェットが縦長（画像を横に合わせる）
            scale = canvas_width / image_width
            # あまり部分の半分を中央に寄せる
            offsety = (canvas_height - image_height * scale) / 2

        # 拡大縮小
        self.scale(scale)
        # あまり部分を中央に寄せる
        self.translate(offsetx, offsety)

    # -------------------------------------------------------------------------------
    # 描画
    # -------------------------------------------------------------------------------

    def draw_image(self,  pil_image):
        
        if pil_image == None:
            return
        
        self.canvas.delete("all")

        # キャンバスのサイズ
        canvas_width = self.canvas.winfo_width()
        canvas_height = self.canvas.winfo_height()

        # キャンバスから画像データへのアフィン変換行列を求める
        #（表示用アフィン変換行列の逆行列を求める）
        mat_inv = np.linalg.inv(self.mat_affine)

        #  PILの画像データをアフィン変換する
        dst = pil_image.transform(
                    (canvas_width, canvas_height),  # 出力サイズ
                    Image.AFFINE,                   # アフィン変換
                    tuple(mat_inv.flatten()),       # アフィン変換行列（出力→入力への変換行列）を一次元のタプルへ変換
                    Image.NEAREST,                  # 補間方法、ニアレストネイバー 
                    fillcolor= self.back_color
                    )

        # 表示用画像を保持
        self.image = ImageTk.PhotoImage(image=dst)

        # 画像の描画
        self.canvas.create_image(
                0, 0,               # 画像表示位置(左上の座標)
                anchor='nw',        # アンカー、左上が原点
                image=self.image    # 表示画像データ
                )

    def redraw_image(self):
        ''' 画像の再描画 '''
        if self. pil_image == None:
            return
        self.draw_image(self.pil_image)


class Application1(tk.Frame):
    def __init__(self,master):
        super().__init__(master,width=500, height=500, borderwidth=4, relief='groove')
        self.master=master
        self.pack()
        self.pack_propagate(0)
        self.create_widgets()
    
    def create_widgets(self):
        #閉じるボタン
        quit_btn=tk.Button(self)
        quit_btn['text']='閉じる'
        quit_btn['command']=self.master.quit
        quit_btn.pack(side='bottom')
        
        
        #リストボックス
        self.items=['グラフ全体','節点とその周りの節点','クリーク','違う色で塗れるかどうか判定','順序確認']
        list_items=tk.StringVar(value=self.items)
        self.list_box=tk.Listbox(self, listvariable=list_items,width=25,height=12)
        self.list_box.pack()
        
        
        #実行ボタン
        submit_btn=tk.Button(self)
        submit_btn['text']='実行'
        submit_btn['command']=self.submit
        submit_btn.pack(side='bottom')
        
        self.message=tk.Message(self,text='見たいグラフを選んでください', width=200)
        self.message.pack()
        
    def submit(self):
        selected_index=self.list_box.curselection()[0]
        print(self.items[selected_index])
        if(selected_index==0):
            self.new_window()
        elif(selected_index==1):
            self.new_window3()
        elif(selected_index==2):
            self.new_window4()
        elif(selected_index==3):
            self.new_window5()
        elif(selected_index==4):
            self.new_window6()
        else:
            print('準備中')
        
        
    def new_window(self):
        str1='合計で'
        str2=str(painted_color_number)
        str3='色で塗れました。'
        text1=str1+str2+str3
        self.sp_window=tk.Toplevel()
        self.app=Application_zoom(self.sp_window, G,new_node_colors,text1)
        self.app.draw_graph()

    def new_window2(self):
        self.new_window2=tk.Toplevel()
        self.app=simple_node(self.new_window2)
        
    def new_window3(self):
        self.new_window3=tk.Toplevel()
        self.app=around_node(self.new_window3)
        
    def new_window4(self):
        self.new_window4=tk.Toplevel()
        self.app=clique(self.new_window4)
        
    def new_window5(self):
        self.new_window5=tk.Toplevel()
        self.app=chigau_iro(self.new_window5)
        
    def new_window6(self):
        self.new_window6=tk.Toplevel()
        self.app=First_step(self.new_window6)

        
class simple_node(tk.Frame):
    def __init__(self,master):
        super().__init__(master)
        self.pack()
        self.master.geometry("500x200")
        self.master.title("彩色グラフ")
        self.create_widgets()
        
    def create_widgets(self):
        #メッセージ
        self.message=tk.Message(self,text='接点番号を入力してください', width=200)
        self.message.pack()
        
        #テキストボックス
        self.text_box1=tk.Entry(self)
        self.text_box1.pack()
        
        
        #選択
        submit_btn=tk.Button(self)
        submit_btn['text']='選択'
        submit_btn['command']=self.submit
        submit_btn.pack(side='bottom')
        
        #閉じるボタン
        quit_btn=tk.Button(self.master)
        quit_btn['text']='閉じる'
        quit_btn['command']=self.master.destroy
        quit_btn.pack(side='bottom')
        
    def submit(self):
        #new_window = tk.Toplevel(self.master)
        #new_window.title("クリークの視覚化")
        
        #値を読み込ませる
        text1=self.text_box1.get()
        #print(text1)
        ver=int(text1)
        
        str1='節点'
        str2=str(ver)
        text1=str1+str2
        # MatplotlibのFigureを作成
        # 節点1とその隣接ノードを持つ部分グラフを抽出
        ego_graph1 = G.subgraph([ver]).copy()
        subgraph_colors = [new_node_colors[node] for node in ego_graph1.nodes()]
        # グラフを描画
        fig, ax = plt.subplots(figsize=(6, 5))
        nx.draw(ego_graph1, pos, with_labels=True, node_color=subgraph_colors, node_size=500, font_size=16, font_color='black', edge_color='gray',ax=ax)
        # FigureCanvasTkAggを使ってTkinterウィジェットにMatplotlibの図を表示
        #canvas = FigureCanvasTkAgg(fig, master=new_window)
        #canvas.draw()
        #canvas.get_tk_widget().pack()
        self.sp_window=tk.Toplevel()
        self.app=Application_zoom(self.sp_window, ego_graph1,subgraph_colors,text1)
        self.app.draw_graph()


class around_node(tk.Frame):
    def __init__(self,master):
        super().__init__(master)
        self.pack()
        self.master.geometry("500x100")
        self.master.title("彩色グラフ")
        self.create_widgets()
        
    def create_widgets(self):
        #メッセージ
        self.message=tk.Message(self,text='接点番号を入力してください', width=200)
        self.message.pack()
        
        #テキストボックス
        self.text_box2=tk.Entry(self)
        self.text_box2.pack()
        
        #閉じるボタン
        quit_btn=tk.Button(self.master)
        quit_btn['text']='閉じる'
        quit_btn['command']=self.master.destroy
        quit_btn.pack(side='bottom')
        
        #実行ボタン
        submit_btn=tk.Button(self)
        submit_btn['text']='実行'
        submit_btn['command']=self.submit
        submit_btn.pack(side='bottom')
        
    def submit(self):
        #new_window = tk.Toplevel(self.master)
        #new_window.title("クリークの視覚化")
        
        #値を読み込ませる
        text2=self.text_box2.get()
        #print(text2)
        ver2=int(text2)
        
        
        str1=str(ver2)
        str2='番とその周りの節点'
        text1=str1+str2
        # MatplotlibのFigureを作成
        # 節点とその隣接ノードを持つ部分グラフを抽出
        ego_graph2 = nx.ego_graph(G, ver2)
        subgraph_colors = [new_node_colors[node] for node in ego_graph2.nodes()]
        
        # グラフを描画
        fig, ax = plt.subplots(figsize=(6, 5))
        #nx.draw(ego_graph2, pos, with_labels=True, node_color=subgraph_colors, node_size=500, font_size=16, font_color='black', edge_color='gray',ax=ax)
        self.sp_window=tk.Toplevel()
        self.app=Application_zoom(self.sp_window, ego_graph2,subgraph_colors,text1)
        # FigureCanvasTkAggを使ってTkinterウィジェットにMatplotlibの図を表示
        #canvas = FigureCanvasTkAgg(fig, master=new_window)
        #canvas.draw()
        #canvas.get_tk_widget().pack()
        self.app.draw_graph()



cliques = list(nx.find_cliques(G))

        
class clique(tk.Frame):
    def __init__(self,master):
        super().__init__(master)
        self.pack()
        self.master.geometry("500x500")
        self.master.title("クリーク")
        self.create_widgets()
        
    def create_widgets(self):
        
        # 節点1とその隣接ノードを持つ部分グラフを抽出
        self.listbox = tk.Listbox(self,height=20)
        
        for i, clique in enumerate(cliques):
            self.listbox.insert(tk.END, f"Clique {i+1}: {clique}")
        self.listbox.pack()
        
        # 実行ボタン
        self.submit_btn = tk.Button(self, text="実行", command=self.show_clique)
        self.submit_btn.pack()
        
        #閉じるボタン
        quit_btn=tk.Button(self.master)
        quit_btn['text']='閉じる'
        quit_btn['command']=self.master.destroy
        quit_btn.pack(side='bottom')
        
    def show_clique(self):
        # 選択されたクリークを取得
        selected_index = self.listbox.curselection()
        if selected_index:
            clique = cliques[selected_index[0]]
            self.open_new_window(clique)
        
    def open_new_window(self, clique):
        #new_window = tk.Toplevel(self.master)
        #new_window.title("クリークの視覚化")
        # MatplotlibのFigureを作成
        
        # 最大クリークを含む部分グラフを作成
        max_clique_subgraph = G.subgraph(clique)
        
        # 部分グラフのノードに対応する色リストを作成
        subgraph_colors = [new_node_colors[node] for node in max_clique_subgraph.nodes()]
        
        # グラフを描画
        fig, ax = plt.subplots(figsize=(6, 5))
        nx.draw(max_clique_subgraph, pos, with_labels=True, node_color=subgraph_colors, node_size=1000, font_size=16, font_color='black', edge_color='black',ax=ax)
        plt.show()
        # FigureCanvasTkAggを使ってTkinterウィジェットにMatplotlibの図を表示
        #canvas = FigureCanvasTkAgg(fig, master=new_window)
        #canvas.draw()
        #canvas.get_tk_widget().pack()
        
max_clique = max(cliques, key=len)  
#クリークの周りの節点を探し出す
connected_nodes = set()
for node in G.nodes:
    if node not in max_clique:
        for clique_node in max_clique:
            if G.has_edge(node, clique_node):
                connected_nodes.add(node)
                break
            
    
sorted_nodes = [[]for _ in range(painted_color_number+1)]
selected_nodes=[]
#色ごとに分ける
for q in range(num_nodes):
    for j in range (painted_color_number+1):
        if node_colors[q]==j:  
            sorted_nodes[j].append(q)
            

            
for y in range(1, painted_color_number+1):
    selected_nodes.append(random.choice(sorted_nodes[y]))
            

extract_six_color_nodes_graph=G.subgraph(selected_nodes)
#print(extract_six_color_nodes_graph)        

got_selected_nodes = selected_nodes
subgraph=nx.Graph()
#print(got_selected_nodes)
connected_nodes2 = set()
for node in G.nodes:
    if node not in got_selected_nodes:
        for a in got_selected_nodes:
            if G.has_edge(node, a):
                connected_nodes2.add(node)
                break
            
subgraph= extract_six_color_nodes_graph
connected_subgraph = G.subgraph(connected_nodes2)
G_combined=nx.compose(subgraph, connected_subgraph)
parts_cliques = list(nx.find_cliques(G_combined))


#色ごとのグラフ
red_team=sorted_nodes[1]
subgraph_red = G.subgraph(red_team)
blue_team=sorted_nodes[2]
#print(blue_team)
subgraph_blue = G.subgraph(blue_team)
green_team=sorted_nodes[3]
subgraph_green = G.subgraph(green_team)
yellow_team=sorted_nodes[4]
subgraph_yellow = G.subgraph(yellow_team)
purple_team=sorted_nodes[5]
subgraph_purple = G.subgraph(purple_team)
orange_team=sorted_nodes[6]
subgraph_orange = G.subgraph(orange_team)
G_combined2=nx.compose(subgraph_red,subgraph_blue)
G_combined3=nx.compose(G_combined2,subgraph_green)
G_combined4=nx.compose(G_combined3,subgraph_yellow)
G_combined5=nx.compose(G_combined4,subgraph_purple)
G_combined6=nx.compose(G_combined5,subgraph_orange)

#色ごとのグラフ
red_team=sorted_nodes[1]
subgraph_red = G.subgraph(red_team)
blue_team=sorted_nodes[2]
#print(blue_team)
subgraph_blue = G.subgraph(blue_team)
green_team=sorted_nodes[3]
subgraph_green = G.subgraph(green_team)
yellow_team=sorted_nodes[4]
subgraph_yellow = G.subgraph(yellow_team)
purple_team=sorted_nodes[5]
subgraph_purple = G.subgraph(purple_team)
orange_team=sorted_nodes[6]
subgraph_orange = G.subgraph(orange_team)
G_combined2=nx.compose(subgraph_red,subgraph_blue)
G_combined3=nx.compose(G_combined2,subgraph_green)
G_combined4=nx.compose(G_combined3,subgraph_yellow)
G_combined5=nx.compose(G_combined4,subgraph_purple)
G_combined6=nx.compose(G_combined5,subgraph_orange)




pos3 = nx.circular_layout(G_combined6)
pos2 = nx.circular_layout(G)
subgraph_red_colors= [new_node_colors[node] for node in subgraph_red]
#nx.draw(G, pos3, with_labels=True, node_color=new_node_colors)
#plt.show()




#B=nx.Graph()
#for color1 in sorted_nodes:
#        for color2 in sorted_nodes:
#            if color1 != color2:  # 異なる色のグループ間でエッジを追加
#                for node1 in color_groups[color1]:
#                  for node2 in color_groups[color2]:
#                        B.add_edge(node1, node2)
    
class chigau_iro(tk.Frame):
    def __init__(self,master):
        super().__init__(master)
        self.pack()
        self.master.geometry("600x600")
        self.master.title("色ごとに分けた図")
        self.create_widgets()
        
    def create_widgets(self):
        #メッセージ
        self.message=tk.Message(self,text='調べたい接点番号を入力してください', width=200)
        self.message.pack()
        
        #テキストボックス
        self.text_box2=tk.Entry(self)
        self.text_box2.pack()
        
        fig, ax = plt.subplots(figsize=(6, 5))
        nx.draw(G, pos3, with_labels=True, node_color=new_node_colors, node_size=500, font_size=16, font_color='black', edge_color='gray',ax=ax)
        canvas = FigureCanvasTkAgg(fig, master=self.master)
        canvas.draw()
        canvas.get_tk_widget().pack()
        
        #閉じるボタン
        quit_btn=tk.Button(self.master)
        quit_btn['text']='閉じる'
        quit_btn['command']=self.master.destroy
        quit_btn.pack(side='bottom')
        
        #実行ボタン
        submit_btn=tk.Button(self)
        submit_btn['text']='実行'
        submit_btn['command']=self.submit
        submit_btn.pack(side='bottom')
        
    def submit(self):
        #new_window = tk.Toplevel(self.master)
        #new_window.title("節点の抜き出し")
        
        #値を読み込ませる
        text2=self.text_box2.get()
        ver2=int(text2)
        
        # MatplotlibのFigureを作成
        # 節点1とその隣接ノードを持つ部分グラフを抽出
        ego_graph2 = nx.ego_graph(G, ver2)
        subgraph_colors = [new_node_colors[node] for node in ego_graph2.nodes()]
        not_used_colors=[]
        for color in used_colors:
            if(color not in subgraph_colors):
                not_used_colors.append(color)
                
        print(not_used_colors)
        if(not_used_colors):
            joined_string = ' '.join(not_used_colors)
            str2=str(joined_string)
            str3='で塗れる可能性があります。'
            text1=str2+str3
            #self.message=tk.Message(master=new_window,text=text1,font=("Times New Roman", 18) ,width=550)
            #self.message.pack()
        else:
            text1=None
        

        
        # グラフを描画
        fig, ax = plt.subplots(figsize=(6, 5))
        nx.draw(ego_graph2, pos3, with_labels=True, node_color=subgraph_colors, node_size=500, font_size=16, font_color='black', edge_color='gray',ax=ax)
        
        # FigureCanvasTkAggを使ってTkinterウィジェットにMatplotlibの図を表示
        #canvas = FigureCanvasTkAgg(fig, master=new_window)
        #canvas.draw()
        #canvas.get_tk_widget().pack()
        self.sp_window=tk.Toplevel()
        self.app=Application_zoom(self.sp_window, ego_graph2,subgraph_colors,text1)
        self.app.draw_graph()

f.close()
#!!ファイルの名前注意!!
# データ読み込み
f = open('step2.txt', 'r')

# データ読み取り
data = f.readline()



# 無効グラフの生成
G = nx.Graph()

numbers = list(map(int, data.split()))
a, b, c = numbers  # a,b,cにそれぞれ節点数、枝数、分割数を代入。

#!!ファイルの名前注意!!
# 行数をカウント
with open('step2.txt', "r") as file:
    line_count = sum(1 for _ in file)
    
#固まり数(Kは大文字)
K=a*2+2
s=line_count/K
#sは表示させる画面の数

num_nodes=a
G.add_nodes_from(range(num_nodes))


j=0
l=1
Ma=[]
Ma2=[]
for i in range(0, line_count, K):
    matrix_np=[]
    matrix_np2=[]
    #!!ファイルの名前注意!!
    with open("step2.txt","r") as file:
        lines = file.readlines()[l:a+l]
        
    with open("step2.txt","r") as file:
        lines2 = file.readlines()[l+a+1:K+i]
        
    rows = lines
    # 各行を空白で分割し、整数型のリストに変換
    matrix = [list(map(int, row.split())) for row in rows]
    # NumPy配列として行列に変換（オプション）
    matrix_np = np.array(matrix)
    
    
    
    Ma.append(matrix_np.copy())
    
    
    rows2 = lines2
    
    
    
    # 各行を空白で分割し、整数型のリストに変換
    matrix2 = [list(map(int, row.split())) for row in rows2]
    
    # NumPy配列として行列に変換（オプション）
    matrix_np2 = np.array(matrix2)
    Ma2.append(matrix_np2.copy())
    
    
    j=j+1
    l=l+K


ma=Ma[0]

# 辺を追加
for v in range(0,num_nodes):
    for t in range(v+1, num_nodes):
        if matrix_np[v, t] == 1:
            G.add_edge(v, t)
# 長さ10の「a」の配列をforループで作成

# 数字を色にマッピングする関数
def map_number_to_color(number):
    color_map = {
    0: 'white',
    1: 'red', 2: 'blue', 3: 'green', 4: 'yellow', 5: 'purple', 6: 'orange', 
    7: 'pink', 8: 'cyan', 9: 'magenta', 10: 'brown', 11: 'lime', 12: 'gray', 
    13: 'olive', 14: 'navy', 15: 'teal', 16: 'gold', 17: 'violet', 18: 'indigo',
    19: 'maroon', 20: 'beige', 21: 'chocolate', 22: 'coral', 23: 'aquamarine',
    24: 'crimson', 25: 'turquoise', 26: 'slateblue', 27: 'khaki', 28: 'peachpuff',
    29: 'peru', 30: 'plum', 31: 'orchid', 32: 'wheat', 33: 'salmon', 34: 'seashell',
    35: 'chartreuse', 36: 'sienna', 37: 'snow', 38: 'rebeccapurple', 39: 'antiquewhite',
    40: 'mediumseagreen', 41: 'lightcoral', 42: 'seagreen', 43: 'lightpink',
    44: 'lemonchiffon', 45: 'cadetblue', 46: 'lawngreen', 47: 'darkorange', 
    48: 'hotpink', 49: 'darkgray', 50: 'mistyrose', 51: 'indianred', 52: 'lightblue', 
    53: 'yellowgreen', 54: 'thistle', 55: 'lightyellow', 56: 'darkviolet',
    57: 'springgreen', 58: 'peachpuff', 59: 'mediumpurple', 60: 'forestgreen',
    61: 'steelblue', 62: 'chocolate', 63: 'firebrick', 64: 'darkslategray', 
    65: 'slategray', 66: 'lightsalmon', 67: 'midnightblue', 68: 'springgreen',
    69: 'darkorchid', 70: 'plum', 71: 'goldenrod', 72: 'lightgreen', 73: 'tomato',
    74: 'burlywood', 75: 'greenyellow', 76: 'lightcyan', 77: 'tan', 78: 'mediumvioletred',
    79: 'gainsboro', 80: 'dodgerblue', 81: 'darkblue', 82: 'lavenderblush', 
    83: 'mediumslateblue', 84: 'chartreuse', 85: 'rebeccapurple', 86: 'darkturquoise',
    87: 'limegreen', 88: 'indigo', 89: 'seashell', 90: 'cornflowerblue', 
    91: 'mistyrose', 92: 'darkgreen', 93: 'aquamarine', 94: 'aliceblue', 
    95: 'lightseagreen', 96: 'seashell', 97: 'lavender', 98: 'mintcream', 
    99: 'mediumseagreen', 100: 'lightsteelblue'
}  # 数字を色に対応
    return color_map.get(number, 'white')

class First_step(tk.Frame):
    def __init__(self,master):
        super().__init__(master)
        self.pack()
        self.master.geometry("200x200")
        self.master.title("彩色グラフ")
        self.count=1
        self.value=0
        self.create_widgets()
        
    def create_widgets(self):
        
        
        ma=Ma[0]
        #print(ma)
        # 辺を追加
        for v in range(0,num_nodes):
            for t in range(v+1, num_nodes):
                if matrix_np[v, t] == 1:
                    G.add_edge(v, t)
        
        Matr=Ma2[0]
        
        # ノードの色を指定
        color1 = [0 for _ in range(a)]  # デフォルトで白色 (カラーマップの最小値)
        
        for i in range(num_nodes):
            for w in range(0, num_nodes):
                if Matr[i, w] == 1:
                    color1[i]=w+1
                    break
        
        
        # カラーリストを作成
        color_list = [map_number_to_color(num) for num in color1]
        
        print(color_list)
        
        
        
        str2='1番目の彩色'
        # MatplotlibのFigureを作成
        fig, ax = plt.subplots(figsize=(5, 5))
        self.sp_window=tk.Toplevel()
        self.app=Application_zoom(self.sp_window,G,color_list,str2)
        
        #nx.draw(G, pos, with_labels=True, node_color=color_list,node_size=500,edgecolors='black', font_size=16, font_color='black', edge_color='gray',ax=ax)
        # FigureCanvasTkAggを使ってTkinterウィジェットにMatplotlibの図を表示
        #canvas = FigureCanvasTkAgg(fig, master=root)
        #canvas.draw()
        #canvas.get_tk_widget().pack()
        def update_value(event):
            self.value = self.scale.get()  # スライダーの現在の値を取得
        
        # スライダーの作成
        self.scale = tk.Scale(self.master, from_=1, to=a, orient=tk.HORIZONTAL)
        self.scale.pack()
        
        # スライダーの動きに応じてリアルタイムで値を表示
        self.scale.bind("<Motion>", update_value)
        
        
        #閉じるボタン
        quit_btn=tk.Button(self.master)
        quit_btn['text']='閉じる'
        quit_btn['command']=self.master.quit
        quit_btn.pack(side='bottom')
        
        
        # ボタンを作成し、クリック時にshow_next_plot関数を呼び出す
        next_button = tk.Button(self.master, text="実行")
        next_button['command']=self.new_window2
        next_button.pack()
        
        
        

    def new_window2(self):
        self.new_window2=tk.Toplevel()
        self.app=next(self.new_window2,self.value-1)


class next(tk.Frame):
    
    def __init__(self,master,count):
        self.master=master
        self.Count=count
        self.master.geometry("200x200")
        self.master.title("次のステップ")
        self.create_widgets(self.master)

    def create_widgets(self,window):
        def update_value(event):
            self.value = self.scale.get()  # スライダーの現在の値を取得
        
        # スライダーの作成
        self.scale = tk.Scale(self.master, from_=1, to=a, orient=tk.HORIZONTAL)
        self.scale.pack()
        # スライダーの動きに応じてリアルタイムで値を表示
        self.scale.bind("<Motion>", update_value)
        
        # ノードの色を指定
        color2 = [0 for _ in range(a)]  # デフォルトで白色 (カラーマップの最小値)
        Matr=Ma2[self.Count]
        
        #閉じるボタン
        quit_btn=tk.Button(self.master)
        quit_btn['text']='閉じる'
        quit_btn['command']=self.master.quit
        quit_btn.pack(side='bottom')
        
        
        # ボタンを作成し、クリック時にshow_next_plot関数を呼び出す
        next_button = tk.Button(self.master, text="実行")
        next_button['command']=self.create_new_window
        next_button.pack()
        
        
        i = 0
        for i in range(0,num_nodes):
            for u in range(0, num_nodes):
                if Matr[i, u] == 1:
                    color2[i]=u+1
                    break
        
        # カラーリストを作成
        color_list2 = [map_number_to_color(num) for num in color2]
        
        str2=str(self.Count+1)+'番目の彩色'
        # MatplotlibのFigureを作成
        fig, ax = plt.subplots(figsize=(5, 5))  # 新しいFigureとAxesを作成
        self.sp_window=tk.Toplevel()
        self.app=Application_zoom(self.sp_window,G,color_list2,str2)
        #nx.draw(G, pos, with_labels=True, node_color=color_list2,node_size=500,edgecolors='black', font_size=16, font_color='black', edge_color='gray',ax=ax)
        # FigureCanvasTkAggを使ってTkinterウィジェットにMatplotlibの図を表示
        #canvas = FigureCanvasTkAgg(fig, master=self.master)
        #canvas.draw()
        #canvas.get_tk_widget().pack()
        
    def create_new_window(self):
        # 新しいトップレベルウィンドウを作成
        new_window = tk.Toplevel(self.master)
        new_window.title("新しい画面")
        new_window.geometry("700x700")
        #self.create_widgets(new_window)
        next_step = next(new_window,self.value-1)


root = tk.Tk()
root.title("メニュー画面")
root.geometry("600x400")
app = Application1(master=root)

# メインループの開始
root.mainloop()
f.close()