#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>


void read_data();
void write_data();
void free_memory();
void paint();

typedef struct VertexInfo {
  int sat;     // 飽和度 (saturation)
  int deg;     // 次数 (degree)
  int* ver;    // 隣接頂点配列 (neighbors)
  int col;     // 色番号 (color)
  int hac;     // 色が割り当てられているかどうか (have color)
  int* exver;  // 拡張隣接行列 (extended vertex matrix)
} VerI;

typedef struct Info {
  int* Vmat;  // 未彩色接点行列 (uncolored vertex matrix)
  int* Cmat;  // 色行列 (color matrix)
  int* exCmat;  //彩色行列・彩色情報 (color_cal用)
  } info;
info* Inf;
VerI* veri;
int iro = 0, AC = 0;
long num;

int node,edge,rem_node = 0;


int main(void){
    FILE* fp_o, * fp_i;


    if ((fp_i = fopen("1.txt", "r")) == NULL) {               //file確認
    printf("input file could not be find\n");
    exit(1);
    }

    if ((fp_o = fopen("step.txt", "w")) == NULL) {               //file確認
    printf("Output file could not be created\n");
    exit(1);
    }

    read_data(fp_i);
    fclose(fp_i);
    
    paint(fp_o);

    write_data(fp_o);
    fclose(fp_o);

    free_memory();  // メモリ解放関数を呼び出す
    
}

void read_data(FILE* fp) {                                    //グラフから読み取り
    int a, b, i, j;

    fscanf(fp, "%d %d", &node, &edge);
    rem_node = node;

    

    veri = (VerI*)malloc(sizeof(VerI) * node);                  //メモリ確保
    Inf = (info*)malloc(sizeof(info) * node);

    if (!veri) {
        printf("Error allocating memory for VerI array\n");
        exit(1);
    }
    if (!Inf) {
        printf("Error allocating memory for Info struct\n");
        exit(1);
    }
    int k;
    
    //    Inf->Cmat = (int*)calloc(node * node, sizeof(int));  // 各色に属する頂点のリスト
    //    Inf->Vmat = (int*)calloc(node, sizeof(int));      // 未彩色接点行列
    //    Inf->exCmat = (int*)calloc(node * node, sizeof(int));// 彩色行列
    //    Inf->c_count = (int*)calloc(node, sizeof(int));   // 各色に含まれる頂点の数
    //    Inf->r_count = (int*)calloc(node, sizeof(int));   // 各色に含まれる隣接頂点の数
    for (i = 0; i < node; i++) {                                //節点行列メモリ確保
    veri[i].ver = (int*)malloc(sizeof(int) * node);
    veri[i].exver = (int*)malloc(sizeof(int) * node);
    Inf[i].Cmat = (int*)malloc(sizeof(int) * node);
    Inf[i].Vmat = (int*)malloc(sizeof(int) * node);
    Inf[i].exCmat = (int*)malloc(sizeof(int)* node);// 彩色行列
    //Inf[i].c_count = (int*)malloc(sizeof(int)* node);   // 各色に含まれる頂点の数
    //Inf[i].r_count = (int*)malloc(sizeof(int)* node);   // 各色に含まれる隣接頂点の数
    for (j = 0; j < node; j++) {                              //初期化
      veri[i].ver[j] = 0;
      veri[i].exver[j] = 0;
      Inf[i].Cmat[j] = 0;
      Inf[i].Vmat[j] = 0;
      Inf[i].exCmat[j] = 0;
      //Inf[i].c_count[j] = 1;
      //Inf[i].r_count[j] = 0;
    }
  }
    
    // メモリ割り当てエラーチェック
    if (!Inf->Cmat || !Inf->Vmat || !Inf->exCmat) {
        printf("Error allocating memory for Info matrices\n");
        exit(1);
    }

    // VerI 構造体のメモリ確保
    for (i = 0; i < node; i++) {
        veri[i].ver = (int*)calloc(node, sizeof(int));   // 隣接頂点配列
        veri[i].exver = (int*)calloc(node, sizeof(int)); // 拡張隣接行列


        // メモリ割り当てエラーチェック
        if (!veri[i].ver || !veri[i].exver) {
            printf("Error allocating memory for adjacency or extended adjacency matrix\n");
            exit(1);
        }
        for (j = 0; j < node; j++) {                              //初期化
        veri[i].ver[j] = 0;
        veri[i].exver[j] = 0;
        Inf[i].Cmat[j] = 0;
        Inf[i].exCmat[j] = 0;
        Inf[i].Vmat[j] = 0;
    }

        veri[i].col = -1;  // 色の初期化（-1 は未彩色）
        veri[i].hac = 0;   // 色割り当てフラグの初期化
    }
    for (i = 0; i < edge; i++) {                                //繋がっているところを１にする
    fscanf(fp, "%d %d", &a, &b);
    veri[a].ver[b] = 1;
    veri[b].ver[a] = 1;
    veri[a].exver[b] = 1;
    veri[b].exver[a] = 1;
    Inf[a].Vmat[b] = 1;
    Inf[b].Vmat[a] = 1;
  }
    
}


void paint(FILE* fp){
    int i,j,k;
    int c_count[node]; // cの各色に含まれる頂点の数
    int r_count[node]; // rの各色に含まれる頂点の数

    memset(c_count, 0, sizeof(c_count));
    memset(r_count, 0, sizeof(r_count));

    
    for (i = 0; i < node; i++) {  // 頂点を選ぶ
    int c2=0;

    while(1){
        int kaburi = 0;
        for (j = 0; j < node; j++) {
            
            
            if (veri[i].ver[j] && Inf[j].Cmat[c2] == 1) {
                kaburi = 1;
                break;
                }
            }
            if (kaburi==1) c2++;
            else break;
        }

        // 色リストを更新
    Inf[i].Cmat[c2] = 1;
    
    
    
    // 隣接リストを更新
    for ( j = 0; j < node; j++) {
        int neighbor = veri[i].ver[j];
        int exists_in_r = 0;
        for ( k = 0; k < node; k++) {
            if (Inf[i].Vmat[k] == neighbor) {
                exists_in_r = 1;
                break;
            }
        }
        if (exists_in_r==0) {
            Inf[i].Vmat[j] = neighbor;
            
        }
    }

        // ACを更新
        if (AC <= c2) {
            AC = c2 + 1;
        }


    write_data(fp);



    }
}




void write_data(FILE* fp){
    int i, j;
    fprintf(fp, "%d %d %d\n", node, edge, AC);                   //節点数を書き込み
    for (i = 0; i < node; i++) {                        //彩色行列、節点行列を書き込み
        for (j = 0; j < node; j++) {
	    fprintf(fp, "%d ", veri[i].ver[j]);                    //隣接行列を書き込み
    }
    fprintf(fp, "\n");
    }
    
    
    fprintf(fp, "\n");
    for (i = 0; i < node; i++) {                                   //彩色行列を書き込み
        for (j = 0; j < node; j++) {
	        fprintf(fp, "%d ",  Inf[i].Cmat[j]);
    }
    fprintf(fp, "\n");
    }
    

}

void free_memory() {
    int i;
    for (i = 0; i < node; i++) {
        free(veri[i].ver);
        free(veri[i].exver);
    }
    free(veri);
    free(Inf->Cmat);
    free(Inf->Vmat);
    free(Inf->exCmat);
    free(Inf);
}

