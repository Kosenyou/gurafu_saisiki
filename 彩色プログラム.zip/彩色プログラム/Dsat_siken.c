//彩色手順を使用回数の大きい順に行う(使用した色の総数and時間を出力)
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/time.h>

// 色ごとの情報（色行列と使用回数、未彩色接点行列）を扱う構造体
typedef struct GraphInfo {
    int* Colormatrix;  // 色行列（色が割り当てられたかどうかを示す）
    int* Uncoloeredvertexmatrix;  // 未彩色接点行列（頂点間の接続）
    int colorcount;  // 色の使用回数
} GraphInfo;

// 頂点情報を扱う構造体
typedef struct VertexInfo {
    int saturation;   // 飽和度
    int degree;   // 次数
    int* Adjacentvertex;  // 隣接頂点行列
    int havecolor;   // 色が割り当てられているかどうか
} VertexInfo;

int node, edge;
GraphInfo* graph_info;
VertexInfo* vertex_info;
int current_color_count = 0;  // 使用している色の総数

typedef long suseconds_t;

void read_data(FILE* fp);
void Dsat();
void free_memory();
void write_data();
int can_use_color(int vertex, int color_index);
int compare_colors(const void* a, const void* b);  // qsort用の比較関数

struct timeval startTime, endTime;  // 構造体宣言

int main(int argc, char* argv[]) {
    gettimeofday(&startTime, NULL);

    FILE* fp_i;
    FILE* fp_o;
    if (argc < 2) {  // ファイル数の確認
        printf("Error::Please input file name\n");
        exit(1);
    }

    if ((fp_i = fopen(argv[1], "r")) == NULL) {  // ファイルの確認
        printf("Input graph does not exist\n");
        exit(1);
    }
    
    if ((fp_o = fopen("step2.txt", "w")) == NULL) {               //file確認
    printf("Output file could not be created\n");
    exit(1);
    }

    read_data(fp_i);
    fclose(fp_i);
    Dsat(fp_o);
    
    write_data(fp_o);
    fclose(fp_o);

    
    free_memory();  // メモリ解放関数を呼び出す
    return 0;
}

void read_data(FILE* fp) {  // グラフから読み取り
    int a, b, i, j;

    fscanf(fp, "%d %d", &node, &edge);
    vertex_info = (VertexInfo*)malloc(sizeof(VertexInfo) * node);
    graph_info = (GraphInfo*)malloc(sizeof(GraphInfo) * node);

    for (i = 0; i < node; i++) {
        vertex_info[i].Adjacentvertex = (int*)malloc(sizeof(int) * node);
        graph_info[i].Colormatrix = (int*)malloc(sizeof(int) * node);
        graph_info[i].Uncoloeredvertexmatrix = (int*)malloc(sizeof(int) * node);
        for (j = 0; j < node; j++) {
            vertex_info[i].Adjacentvertex[j] = 0;
            graph_info[i].Colormatrix[j] = 0;
            graph_info[i].Uncoloeredvertexmatrix[j] = 0;
        }
        graph_info[i].colorcount = 0;  // 色使用回数の初期化
    }

    for (i = 0; i < edge; i++) {  // エッジを読み込み、隣接行列を作成
        fscanf(fp, "%d %d", &a, &b);
        vertex_info[a].Adjacentvertex[b] = 1;
        vertex_info[b].Adjacentvertex[a] = 1;
        graph_info[a].Uncoloeredvertexmatrix[b] = 1;  // 未彩色接点行列に隣接情報を設定
        graph_info[b].Uncoloeredvertexmatrix[a] = 1;
    }

    for (i = 0; i < node; i++) {  // degreeの整理
        for (j = 0; j < node; j++) {
            vertex_info[i].degree += vertex_info[i].Adjacentvertex[j];
        }
        vertex_info[i].saturation = 0;  // saturation の初期設定
        vertex_info[i].havecolor = 0;  // 初期色設定
    }
}

void Dsat(FILE* fp) {
    int i, k, l, Usedvertexcounter = 0 ,iro = 0;

    while (Usedvertexcounter < node) {  // Usedvertexcounter(回数)が node と同じになるまで
        int selected_vertex = -1,j= -1,sai =0;

        // 彩色する頂点を選ぶ（飽和度優先、次数が高いものを優先）
       for (i = 0; i < node; i++) {
            if (vertex_info[i].havecolor == 0) {
                if (selected_vertex == -1) {
                    selected_vertex = i;
                } else {
                    if (vertex_info[selected_vertex].saturation < vertex_info[i].saturation) {
                        selected_vertex = i;
                    } else if (vertex_info[selected_vertex].saturation == vertex_info[i].saturation) {
                        if (vertex_info[selected_vertex].degree < vertex_info[i].degree) {
                            selected_vertex = i;
                        }
                    }
                }
            }
        }

        vertex_info[selected_vertex].havecolor = 1;  // selected_vertex に色を与える

        // 使用回数によって色をソートし、その順序で試す
        int* color_order = (int*)malloc(sizeof(int) * current_color_count);
        for (i = 0; i < current_color_count; i++) {
            color_order[i] = i;
        }
        qsort(color_order, current_color_count, sizeof(int), compare_colors);  // qsortで色をソート

        // 使用回数が多い順に色を試す
        int selected_color = -1;
        for (i = 0; i < current_color_count; i++) {
            if (can_use_color(selected_vertex, color_order[i])) {  // 既存色が使えるかどうか
                selected_color = color_order[i];
                break;
            } 
            
        }

        // どの既存色も使えない場合、新しい色を追加
        if (selected_color == -1) {
            selected_color = current_color_count;
            current_color_count++;
        }

        // 選んだ色を頂点 selected_vertex に設定
        graph_info[selected_color].Colormatrix[selected_vertex] = 1;
        graph_info[selected_color].colorcount++;  // 色の使用回数をカウント

        

        for (k = 0; k < node; k++) {
            graph_info[selected_vertex].Uncoloeredvertexmatrix[k] = 0;
            graph_info[k].Uncoloeredvertexmatrix[selected_vertex] = 0;
        }

        // degree と saturation の初期化
        for (k = 0; k < node; k++) {
            vertex_info[k].degree = 0;
            vertex_info[k].saturation = 0;
        }

        // degree の更新
        for (k = 0; k < node; k++) {
            for (l = 0; l < node; l++) {
                vertex_info[k].degree += graph_info[k].Uncoloeredvertexmatrix[l];
            }
        }

        // saturation の更新
        for (j = 0; j < node; j++) {
            for (k = 0; k < node; k++) {
                for (l = 0; l < node; l++) {
                    sai = vertex_info[j].Adjacentvertex[l] * graph_info[k].Colormatrix[l];
                    if (sai != 0)
                        break;
                }
                vertex_info[j].saturation += sai;
            }
            sai = 0;
        }
        //printf("%d,%d\n",Usedvertexcounter,current_color_count);
        Usedvertexcounter++;
        write_data(fp);
        free(color_order); // メモリの解放
    }

    

    gettimeofday(&endTime, NULL);
    // 実行時間の計算
    time_t diffsec = difftime(endTime.tv_sec, startTime.tv_sec);
    suseconds_t diffsub = endTime.tv_usec - startTime.tv_usec;
    double realsec = diffsec + diffsub * 1e-6;

    printf("%d,%f \n" ,current_color_count,realsec);
}

// 頂点 vertex に対して、 color_index の色が使えるかどうかを判定する関数
int can_use_color(int vertex, int color_index) {
    for (int i = 0; i < node; i++) {
        if (vertex_info[vertex].Adjacentvertex[i] == 1 && graph_info[color_index].Colormatrix[i] == 1) {
            return 0;  // 隣接する頂点に同じ色がある場合は使えない
        }
    }
    return 1;  // 使用可能
}


// qsort用の比較関数
int compare_colors(const void* a, const void* b) {
    int color_a = *(const int*)a;
    int color_b = *(const int*)b;
    // 使用回数の降順でソート
    return graph_info[color_b].colorcount - graph_info[color_a].colorcount;
}

void write_data(FILE* fp){
    int i, j;
    fprintf(fp, "%d %d %d\n", node, edge, current_color_count);                   //節点数を書き込み
    for (i = 0; i < node; i++) {                        //彩色行列、節点行列を書き込み
        for (j = 0; j < node; j++) {
	    fprintf(fp, "%d ", vertex_info[i].Adjacentvertex[j]);                    //隣接行列を書き込み
    }
    fprintf(fp, "\n");
    }
    
    
    fprintf(fp, "\n");
    for (i = 0; i < node; i++) {                                   //彩色行列を書き込み
        for (j = 0; j < node; j++) {
	        fprintf(fp, "%d ",  graph_info[j].Colormatrix[i]);
    }
    fprintf(fp, "\n");
    }
    

}

void free_memory() {
    // vertex_info の解放
    for (int i = 0; i < node; i++) {
        free(vertex_info[i].Adjacentvertex);  // Adjacentvertex 配列の解放
    }
    free(vertex_info);  // vertex_info 配列自体の解放

    // graph_info の解放
    for (int i = 0; i < node; i++) {
        free(graph_info[i].Colormatrix);  // Colormatrix 配列の解放
        free(graph_info[i].Uncoloeredvertexmatrix);  // Uncoloeredvertexmatrix 配列の解放
    }
    free(graph_info);  // graph_info 配列自体の解放

    

}